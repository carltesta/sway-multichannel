SwayS {

	classvar <>short_win=1, <>long_win=30;

	var <>name, <>numChan, <>input, <>analysis_input, <>processing, <>fade=30, <>output,
	<>density, <>clarity, <>amplitude, <>tempo,
	<current_processing, <>processors, <>modulators, <>spatializers,
	<>task;



	new {
		this.init;
	}

init {
		|givenName="sway",numChannels=1|

		//assign name of channel
		name = givenName;
		numChan = numChannels;

		//audio input

		input = NodeProxy.audio(Server.default, numChan)
		.source = { |chan=0| SoundIn.ar(chan,1.neg) };

		//analysis input

		analysis_input = NodeProxy.audio(Server.default, numChan)
		.source = { |chan=0| SoundIn.ar(chan) };

		//processing

		processing = NodeProxy.audio(Server.default, numChan).fadeTime_(fade)
		.source = { Silent.ar(1) }; //start with silent processing

		//output

			output = NodeProxy.audio(Server.default, numChan)
			.source = { processing.ar(1) };

		//build analysis on start
		this.build_analysis;

		//define verbose task
		this.verboseTask;
}

build_analysis {

		density = NodeProxy.control(Server.default, 2)
		.source = {
			//Density Tracker
			var buf = LocalBuf.new(512,1);
			var onsets = Onsets.kr(FFT(buf, analysis_input.ar(1)));
			var shortStats = OnsetStatistics.kr(onsets, short_win);
			var longStats = OnsetStatistics.kr(onsets, long_win);
			var shortValue = (shortStats[0]/short_win);
			var longValue = (longStats[0]/long_win);
			[shortValue, longValue];
		};

		amplitude = NodeProxy.control(Server.default, 2)
		.source = {
			//Amplitude Tracker
			var chain = FFT(LocalBuf(1024), analysis_input.ar(1));
            var loudness = Loudness.kr(chain);
			var shortAverage = AverageOutput.kr(loudness, Impulse.kr(short_win.reciprocal));
			var longAverage = AverageOutput.kr(loudness, Impulse.kr(long_win.reciprocal));
			[shortAverage, longAverage];
		};

		clarity = NodeProxy.control(Server.default, 2)
		.source = {
			var freq, hasFreq, shortAverage, longAverage;
			//Pitch hasfreq Tracker
			# freq, hasFreq = Pitch.kr(analysis_input.ar(1));
            shortAverage = AverageOutput.kr(hasFreq,Impulse.kr(short_win.reciprocal));
			longAverage = AverageOutput.kr(hasFreq,Impulse.kr(long_win.reciprocal));
			[shortAverage, longAverage];
		};

		tempo = NodeProxy.control(Server.default, 1)
		.source = {
			//add some variation of BeatTrack here
		};

	}

	addProcessor {|name, key, func, fadeTime = 1|
		(this.processors.isNil).if({
			processors = Dictionary.new;
	});
	this.processors.put(key, Dictionary[
		\name -> name,
		\func -> func,
		\fadeTime -> fadeTime
	]);
}

runProcessor {|key|
	var processor = this.processors[key];

	(processor.isNil.not).if({
		//processing.source.fadeTime = processor[\fadeTime];
		processing.source = processor[\func].value(this);
		(this.name++": " ++ processor[\name]).postln;
		current_processing = processor[\name];
	}, {
		"Processor does not exist".postln;
	})
}

	getModulatorNode {|key|
	^this.modulators[key][\node];
}

addModulator {|name, key, func, reversePolarityFunc, fadeTime = 1|
		(this.modulators.isNil).if({
			modulators = Dictionary.new;
	});
	this.modulators.put(key, Dictionary[
		\name -> name,
		\func -> func,
		\reversePolarityFunc -> reversePolarityFunc,
		\fadeTime -> fadeTime,
		\node -> NodeProxy(Server.default, 'control', 1)
	]);
}

runModulator {|key, reversePolarity = false|
	var modulator = this.modulators[key],
	node = modulator[\node],
	funcKey = (reversePolarity).if({ \reversePolarityFunc }, { \func });

	(modulator.isNil.not).if({
		//node.source.fadeTime = modulator[\fadeTime];
		node.source = modulator[funcKey].value(this);
		this.modulators[key] = modulator;
		// (this.name++": " ++ modulator[\name]).postln;
		// current_processing = modulator[\name];
	}, {
		"Modulator does not exist".postln;
	})
}

analysisGUI { |window|
		var view = View.new(window);
		view.decorator = FlowLayout(window.view.bounds, 10@10,20@5);

	}

	verboseTask {
		task = TaskProxy({
	loop {
		1.0.wait;

			this.density.bus.get({|val| ("density: "++val).postln});
			this.clarity.bus.get({|val| ("clarity: "++val).postln});
			this.amplitude.bus.get({|val| ("amp: "++val).postln});
		}});

	}

	verbose { |boolean=false|
		boolean.if({
			task.play},
		{task.stop});
		}

addSpatializer {|name, key, func, fadeTime = 1|
		(this.spatializers.isNil).if({
			spatializers = Dictionary.new;
	});
	this.spatializers.put(key, Dictionary[
		\name -> name,
		\func -> func,
		\fadeTime -> fadeTime
	]);

}

}